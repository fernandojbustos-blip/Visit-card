import os

def generate_vcard(name, title, organization, phone, email, website, brief_url, filename):
    vcard_content = f"""BEGIN:VCARD
VERSION:3.0
FN:{name}
ORG:{organization}
TITLE:{title}
TEL;TYPE=WORK,VOICE:{phone}
EMAIL;TYPE=INTERNET:{email}
URL:{website}
NOTE:Brief de servicios: {brief_url}
END:VCARD"""

    with open(filename, "w") as f:
        f.write(vcard_content)
    print(f"vCard generado: {filename}")

if __name__ == "__main__":
    name = "Fernando Bustos O."
    title = "Consultor Senior"
    organization = "GO-UP"
    phone = "+56981560433"
    email = "fernando@go-up.cl" # Asumiendo un correo, ya que no se proporcionó uno específico para el vCard
    website = "https://www.uaplatam.com"
    brief_url = "https://drive.google.com/file/d/1mKBJ6oiDgyCA3pCid-_mFKMG6fbg-8TA/view?usp=drive_link"
    
    generate_vcard(name, title, organization, phone, email, website, brief_url, "Fernando_Bustos_GO-UP.vcf")
