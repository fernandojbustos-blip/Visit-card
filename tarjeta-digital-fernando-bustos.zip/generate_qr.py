#!/usr/bin/env python3
import qrcode
from PIL import Image

def generate_qr_code(url, filename):
    """Genera un código QR para la URL proporcionada"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    # Crear imagen del QR
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(filename)
    print(f"Código QR generado: {filename}")

if __name__ == "__main__":
    # URL del brief de servicios
    brief_url = "https://drive.google.com/file/d/1mKBJ6oiDgyCA3pCid-_mFKMG6fbg-8TA/view?usp=drive_link"
    
    # Generar QR
    generate_qr_code(brief_url, "qr_brief_servicios.png")
